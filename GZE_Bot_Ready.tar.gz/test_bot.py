#!/usr/bin/env python3
"""
Локальный тест бота перед развертыванием на Railway
Запусти: python test_bot.py
"""

import os
from dotenv import load_dotenv
from anthropic import Anthropic

# Загружаем переменные окружения
load_dotenv()

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")

print("=" * 50)
print("🧪 ТЕСТ БОТА GZE GROUP")
print("=" * 50)

# Проверка переменных
print("\n✓ Проверка конфигурации...")

if not TELEGRAM_TOKEN:
    print("❌ ОШИБКА: TELEGRAM_TOKEN не найден в .env")
    exit(1)
print("✅ Telegram Token загружен")

if not ANTHROPIC_API_KEY:
    print("❌ ОШИБКА: ANTHROPIC_API_KEY не найден в .env")
    exit(1)
print("✅ Anthropic API Key загружен")

# Тестируем Claude
print("\n✓ Проверка Claude API...")
try:
    client = Anthropic()
    
    response = client.messages.create(
        model="claude-3-5-sonnet-20241022",
        max_tokens=100,
        messages=[
            {
                "role": "user",
                "content": "Привет! Ты активен? Ответь коротко."
            }
        ]
    )
    
    print(f"✅ Claude API работает")
    print(f"   Ответ: {response.content[0].text}")
    
except Exception as e:
    print(f"❌ ОШИБКА Claude: {e}")
    exit(1)

# Проверка БД
print("\n✓ Проверка базы данных...")
try:
    import sqlite3
    conn = sqlite3.connect("gze_finance.db")
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS test (
            id INTEGER PRIMARY KEY,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()
    print("✅ SQLite работает")
except Exception as e:
    print(f"❌ ОШИБКА БД: {e}")
    exit(1)

print("\n" + "=" * 50)
print("🎉 ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ!")
print("=" * 50)
print("\nТеперь ты готов:")
print("1. Запустить локально: python gze_bot.py")
print("2. Или развернуть на Railway (смотри DEPLOY_GUIDE.md)")
print("\nВ Telegram напиши боту @GZE1111_bot: /start")
